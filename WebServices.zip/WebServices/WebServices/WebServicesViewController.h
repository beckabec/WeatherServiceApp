//
//  WebServicesViewController.h
//  WebServices
//
//  Created by asuuser on 2/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WebServicesViewController : UIViewController
{
    //---outlets---
    IBOutlet UITextField *ipAddress;
    IBOutlet UIActivityIndicatorView *activityIndicator;
    //---web service access---
    NSMutableData *webData;
    NSMutableString *soapResults;
    NSURLConnection *conn;
    //---xml parsing---
    NSXMLParser *xmlParser;
    BOOL *elementFound;
}

@property (nonatomic, strong) UITextField *ipAddress;
@property (nonatomic, strong) UIActivityIndicatorView *activityIndicator;
- (IBAction)buttonClicked:(id)sender;

@end
