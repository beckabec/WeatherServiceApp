//
//  WebServicesTests.h
//  WebServicesTests
//
//  Created by asuuser on 2/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface WebServicesTests : SenTestCase

@end
