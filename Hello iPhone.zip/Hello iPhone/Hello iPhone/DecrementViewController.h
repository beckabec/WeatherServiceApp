//
//  DecrementViewController.h
//  Hello iPhone
//
//  Created by asuuser on 1/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DecrementViewController : UIViewController {
    int count;
}

@property (nonatomic, retain) IBOutlet UILabel *countLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andCount:(int)c;

@end
