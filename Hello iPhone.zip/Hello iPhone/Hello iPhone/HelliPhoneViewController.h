//
//  HelliPhoneViewController.h
//  Hello iPhone
//
//  Created by asuuser on 1/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DecrementViewController.h" // just adding this line

@interface HelliPhoneViewController : UIViewController {
    UILabel *countLabel ;
    int counter ;
}

@end
