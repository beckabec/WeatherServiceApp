//
//  HelliPhoneViewController.m
//  Hello iPhone
//
//  Created by asuuser on 1/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "HelliPhoneViewController.h"

@implementation HelliPhoneViewController

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

-(void)buttonPressed {
    
    // increment our counter 
    counter++;
    
    // update the label’s text, converting from an int to an NSString 
    // note the similarity of stringWithFormat to printf!
    [ countLabel setText : [ NSString stringWithFormat :@"%d" , counter ] ] ;
}

-(void)nextButtonPressed {
    // create an instance of our second view controller
    DecrementViewController *nextVC = [DecrementViewController alloc];
    
    // initialize it from our XIB (interface builder) file
    // note: nil is objective−c for null
    nextVC = [nextVC initWithNibName:@"DecrementViewController" bundle:nil];
    
    // the above typically happens in one line , but we ’ re new to this !
    
    // now, push the new controller onto our navigation view stack:
    [self.navigationController pushViewController:nextVC animated:YES];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    counter = 0;
    
    CGRect labelsize = CGRectMake(10, 10, 300, 20); // x, y, width, height
    
    // note that we keep a pointer in a variable , not a whole object
    countLabel = [[UILabel alloc] initWithFrame:labelsize];
   
    // set some initial text
    // ”This is a C string”
    // @”This is an NSString” −− NSString is the library objective−c string class 
    [countLabel setText:@"Hello World"];
    
    // it’s nice to make things ugly so we can see them better
    [ countLabel setBackgroundColor : [ UIColor cyanColor ] ] ;
    
    // add the label to our view, remember this object manages our view
    [ self . view addSubview : countLabel ] ;
    
    
    
    // ADDING OUR INCREMENT BUTTON
    
    // Use a convience method of UIButton to allocate and construct our button
    UIButton *incrementButton = [ UIButton buttonWithType : UIButtonTypeRoundedRect ] ;
    
    // we still need to tell it size and location
    [incrementButton setFrame:CGRectMake(10, 50, 300, 40) ];
    
    // possibly a good idea to add some text to it
    // there are several button states (normal , highlighted , selected , disabled ) 
    [ incrementButton addTarget : self
                         action :@selector(buttonPressed)
                forControlEvents:UIControlEventTouchUpInside];
    
    [incrementButton setTitle:@"Increment" forState:UIControlStateNormal]; 
    [incrementButton setTitle:@"Ouch!" forState:UIControlStateHighlighted];
    
    // add the button to our view
    [ self . view addSubview : incrementButton ] ;
    
    
    
    // ADDING OUT NEXT BUTTON 
    UIButton *nextButton = [ UIButton buttonWithType : UIButtonTypeRoundedRect ] ;
    [nextButton setFrame:CGRectMake(10, 110, 300, 40) ];
    [nextButton setTitle:@"Next!" forState:UIControlStateNormal];
    [nextButton addTarget : self
                         action :@selector(nextButtonPressed)
                forControlEvents:UIControlEventTouchUpInside];
    [ self . view addSubview : nextButton ] ;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
