//
//  Hello_iPhoneTests.m
//  Hello iPhoneTests
//
//  Created by asuuser on 1/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Hello_iPhoneTests.h"

@implementation Hello_iPhoneTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Hello iPhoneTests");
}

@end
