//
//  Hello_iPhoneTests.h
//  Hello iPhoneTests
//
//  Created by asuuser on 1/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Hello_iPhoneTests : SenTestCase

@end
