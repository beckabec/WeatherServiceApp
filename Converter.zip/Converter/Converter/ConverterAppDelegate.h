//
//  ConverterAppDelegate.h
//  Converter
//
//  Created by asuuser on 1/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ConverterViewController;

@interface ConverterAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ConverterViewController *viewController;

@end
