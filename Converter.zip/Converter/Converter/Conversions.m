//
//  Conversions.m
//  Converter
//
//  Created by asuuser on 1/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Conversions.h"

@implementation Conversions

+(float)tablespoonsForCups:(float)cups 
{
    return cups * 16;
}

@end
