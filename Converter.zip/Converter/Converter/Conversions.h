//
//  Conversions.h
//  Converter
//
//  Created by asuuser on 1/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Conversions : NSObject

+(float)tablespoonsForCups:(float)cups;

@end
