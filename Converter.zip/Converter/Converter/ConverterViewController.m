//
//  ConverterViewController.m
//  Converter
//
//  Created by asuuser on 1/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ConverterViewController.h"

@implementation ConverterViewController

@synthesize resultLabel = _resultLabel;
@synthesize cupLabel = _cupLabel;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (BOOL)textFieldShouldReturn:(UITextField *)textField 
{
    NSLog(@"typed_%@", textField.text); //%@ for any NSObject
    float cupsValue = [textField.text floatValue];
    float tbsValue = [Conversions tablespoonsForCups:cupsValue];
    
    if(tbsValue == 1)
    {   
        self.resultLabel.text = [NSString stringWithFormat:@"%.2f tablespoon", tbsValue];
    }
    else
    {
        self.resultLabel.text = [NSString stringWithFormat:@"%.2f tablespoons", tbsValue];
    }
    
    if(cupsValue == 1)
    {   
        self.cupLabel.text = [NSString stringWithFormat:@"cup is"];
    }
    else
    {
        self.cupLabel.text = [NSString stringWithFormat:@"cups is"];
    }
    
    return YES;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.resultLabel.text = @"tablespoons";
    self.cupLabel.text = @"cups is";
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
